from setuptools import setup

setup(
    name="PineappleDev",
    version="1.2",
    description="Paquete basado en Piña++, inventado por los jajas",
    author="x04000",
    url="www.github.com/x04000",
    packages=["pineappledev"]
)